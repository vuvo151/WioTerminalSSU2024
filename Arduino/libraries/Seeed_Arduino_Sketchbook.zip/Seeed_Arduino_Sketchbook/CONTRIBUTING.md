## Contributing guidelines

All guidelines for contributing to the Seeed_Arduino_Sketchbook repository can be found at [`How to contribute guideline`](https://github.com/Seeed-Studio/Seeed_Arduino_Sketchbook/wiki/How_to_contribute).
