#pragma once

void CliMode();
