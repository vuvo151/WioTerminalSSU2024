#ifndef IMGARRAY_H
#define IMGARRAY_H
#include <stdint.h>

extern const int imsArr[]; // Declare imsArr array

extern const uint32_t ssuLogo[]; // Declare imsArr array

extern const uint32_t humidLogo[];
extern const uint32_t tempLogo[];

#endif


